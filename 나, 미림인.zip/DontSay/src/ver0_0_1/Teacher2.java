package ver0_0_1;

// Lv.2 영철쌤, 지훈쌤, 지웅쌤

public class Teacher2 {

}
