package ver0_0_1;

// Lv.5 교장쌤

public class TeacherBoss {

}
