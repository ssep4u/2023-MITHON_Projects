package com.example.plogging;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Join extends AppCompatActivity {
    private EditText edtId;
    private EditText edtPw;
    private EditText edtEmail;
    private EditText edtPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        Button btnJoin = findViewById(R.id.btnJoin);
        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 사용자가 회원가입 버튼을 클릭했을 때 실행되는 코드
                String id = edtId.getText().toString();
                String userpw = edtPw.getText().toString();
                String username = edtEmail.getText().toString();
                String userphone = edtPhone.getText().toString();

                Log.e("test", username);
                // 서버로 전송할 URL
                String url = "http://192.168.11.116/php_plogging/user.php";

                // HTTP 요청을 보내는 AsyncTask 실행
                new HttpAsyncTask().execute(url, username, id, userpw, userphone);
            }
        });
    }
}