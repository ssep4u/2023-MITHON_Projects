const mysql = require('mysql2');
const nodemailer = require('nodemailer');
const randomstring = require('randomstring');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '1011',
  database: 'whatismoney'
});

// 회원가입 컨트롤러
exports.signup = (req, res) => {
  const { userid, pw, email } = req.body;

  const sql = 'INSERT INTO users (userid, pw, email) VALUES (?, ?, ?)';
  connection.query(sql, [userid, pw, email], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Error registering user' });
    }

    res.status(200).json({ message: 'User registered successfully' });
  });
};

// 아이디 중복 확인 컨트롤러
exports.checkDuplicate = (req, res) => {
  const { userid } = req.body;
  const checkDuplicateSql = 'SELECT COUNT(*) AS count FROM users WHERE userid = ?';
  connection.query(checkDuplicateSql, [userid], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Error checking duplicate user' });
    }
    res.status(200).json({ isDuplicate: result[0].count > 0 });
  });
};

// 이메일 인증 코드 요청 컨트롤러
exports.certificate = (req, res) => {
  const { email } = req.body;

  // 기존에 해당 이메일로 생성된 인증 코드가 있다면 삭제
  const deleteAuthCodeSql = 'DELETE FROM verification_codes WHERE email = ?';
  connection.query(deleteAuthCodeSql, [email], (deleteErr) => {
    if (deleteErr) {
      console.error(deleteErr);
      return res.status(500).json({ error: '기존 인증 코드를 삭제하는 중 오류가 발생하였습니다.' });
    }

    // 새로운 랜덤한 4자리 숫자 생성
    const verificationCode = Math.floor(1000 + Math.random() * 9000);
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'jamda831@gmail.com',
        pass: 'nhvluiqogrktkieu',
      },
    });
    const mailOptions = {
      to: email,
      subject: '이메일 인증',
      html: `
        <div style="margin: 5%; margin-bottom: 6px;">
          <p style="width: 50%; color:#FF6666; font-weight: bolder; font-size: 50px; margin-bottom: 0">돈이뭐지?</p>
        </div>
        <div style="height: 2px; width: 90%; margin-left: 5%; background-color: #A266BE;"></div>
        <h2 style="margin-left: 5%; margin-top: 30px; margin-bottom: 30px;">고객님의 인증번호는 다음과 같습니다.</h2>
        <div style=" height: 230px; width: 90%; margin-left: 5%; border: 2px solid #C1C1C1">
            <p style="color: #6B6B6B; text-align: center;">아래 인증번호 4자리를 인증번호 입력창에 입력해주세요</p>
            <div style="text-align: center; font-size: 80px; vertical-align: middle; letter-spacing: 10px;">${verificationCode}</div>
        </div>
        <p style="margin-left: 5%; margin-top: 20px;">
            인증번호를 요청하지 않았다면 이 메일을 무시하셔도 됩니다.<br>
            누군가 귀하의 이메일 주소를 잘못 입력한 것을 수도 있습니다.<br>
            <br>
            감사합니다.
        </p>
      `,
    };
    const insertAuthCodeSql = 'INSERT INTO verification_codes (email, code) VALUES (?, ?)';
    connection.query(insertAuthCodeSql, [email, verificationCode], (insertErr) => {
      if (insertErr) {
        console.error(insertErr);
        return res.status(500).json({ error: '이메일을 발송하는 중 오류가 발생하였습니다.' });
      }
      transporter.sendMail(mailOptions, (sendMailError, info) => {
        if (sendMailError) {
          console.error(sendMailError);
          return res.status(500).json({ error: '이메일 전송 중에 오류가 발생했습니다.' });
        }
        console.log(info);
        return res.status(200).json({ message: '이메일이 성공적으로 전송되었습니다.' });
      });
    });
  });
};

// 인증번호 확인 함수
exports.checkAuthCode = (req, res) => {
  const { email, code } = req.body;

  // 사용자가 입력한 이메일과 인증번호를 검색하여 확인
  const checkAuthCodeSql = 'SELECT * FROM verification_codes WHERE email = ? AND code = ?';
  connection.query(checkAuthCodeSql, [email, code], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Error checking auth code' });
    }

    // 결과에서 매치되는 레코드를 찾지 못하면 인증 실패
    if (result.length === 0) {
      return res.status(200).json({ message: '인증번호가 일치하지 않습니다.' });
    }

    // 인증 성공
    return res.status(200).json({ message: '인증번호가 확인되었습니다.' });
  });
};

// 로그인 컨트롤러
exports.login = (req, res) => {
  const { userid, pw } = req.body;
  const token = randomstring.generate(40);
  const sql = 'SELECT * FROM users WHERE userid = ? AND pw = ?';
  connection.query(sql, [userid, pw], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: '로그인 중 오류가 발생했습니다.' });
    }

    if (result.length === 0) {
      return res.status(401).json({ error: '잘못된 자격 증명' });
    }

    const userData = {
      userid: result[0].userid,
      token: token,
      hasProfile: result[0].hasProfile,
    };

    // 사용자 정보에 토큰 업데이트
    connection.query('UPDATE users SET accesstoken = ? WHERE userid = ?', [token, userid], (updateErr, updateResult) => {
      if (updateErr) {
        console.error(updateErr);
        return res.status(500).json({ error: '토큰 업데이트 중 오류가 발생했습니다.' });
      }
      return res.status(200).json(userData);
    });
  });
};

// 프로필 설정 컨트롤러
exports.setProfile = (req, res) => {
  const { userid, consume_month } = req.body;

  const sql = 'UPDATE users SET consume_month = ?, hasProfile = 1 WHERE userid = ?';
  connection.query(sql, [consume_month, userid], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: '프로필 업데이트 중 오류가 발생했습니다.' });
    }

    if (result.affectedRows === 0) {
      return res.status(401).json({ error: '잘못된 자격 증명' });
    }

    return res.status(200).json({ message: '프로필이 성공적으로 설정되었습니다.' });
  });
};

exports.saveAccountEntry = (req, res) => {
    const { userid, selectedDate, title, content, entries, status_today } = req.body;
    console.log(req.body);
    const sql = 'INSERT INTO account_book (userid, created_at, title, content, category, income_spending, spending_title, status_today) VALUES (?, ?, ?, ?, ?, ?, ?,?)';

    // entries 배열을 반복하여 데이터베이스에 저장
    for (const entry of entries) {
        connection.query(sql, [userid, selectedDate, title, content, entry.category, entry.income_spending, entry.spending_title, status_today], (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: '가계부 항목을 추가하는 중 오류가 발생했습니다.' });
            }
        });
    }

    return res.status(200).json({ message: '가계부 항목 추가 완료' });
};

// 서버 컨트롤러
exports.getUserData = (req, res) => {
    const { userid } = req.body;

    // 데이터베이스 쿼리를 사용하여 날짜와 status_today 값 불러오기
    const sql = 'SELECT created_at, status_today FROM whatismoney.account_book WHERE userid = ?';

    connection.query(sql, [userid], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: '오류가 발생했습니다.' });
        }

        if (result.length === 0) {
            return res.status(401).json({ error: '데이터를 찾을 수 없습니다.' });
        }

        // 결과 배열을 저장할 빈 배열 생성
        const data = [];

        // 결과 배열을 반복하며 데이터 추출
        result.forEach((row) => {
            data.push({
                created_at: row.created_at,
                status_today: row.status_today
            });
        });

        // 클라이언트에 응답 전송
        return res.status(200).json({
            data: data
        });
    });
};



exports.gettraffic = (req, res) => {
    const { userid } = req.body;

    const traffic = '교통비';

    const sql = 'SELECT category, income_spending, spending_title FROM whatismoney.account_book WHERE userid = ? AND MONTH(created_at) = 10 AND category = ?';
    connection.query(sql, [userid, traffic], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: '오류가 발생했습니다.' });
        }

        if (result.length === 0) {
            return res.status(401).json({ error: '데이터를 찾을 수 없습니다.' });
        }

        // 결과 배열을 저장할 빈 배열 생성
        const data = [];

        // 결과 배열을 반복하며 데이터 추출
        result.forEach((row) => {
            data.push({
                category: row.category,
                income_spending: row.income_spending, 
                spending_title: row.spending_title
            });
        });

        // 클라이언트에 응답 전송
        return res.status(200).json({
            data: data
        });
    });
};

exports.geteat = (req, res) => {
    const { userid } = req.body;

    const eat = '식비';

    const sql = 'SELECT category, income_spending, spending_title FROM whatismoney.account_book WHERE userid = ? AND MONTH(created_at) = 10 AND category = ?';
    connection.query(sql, [userid, eat], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: '오류가 발생했습니다.' });
        }

        if (result.length === 0) {
            return res.status(401).json({ error: '데이터를 찾을 수 없습니다.' });
        }

        // 결과 배열을 저장할 빈 배열 생성
        const data = [];

        // 결과 배열을 반복하며 데이터 추출
        result.forEach((row) => {
            data.push({
                category: row.category,
                income_spending: row.income_spending, 
                spending_title: row.spending_title
            });
        });

        // 클라이언트에 응답 전송
        return res.status(200).json({
            data: data
        });
    });
};

exports.gethobby = (req, res) => {
    const { userid } = req.body;

    const hobby = '취미';

    const sql = 'SELECT category, income_spending, spending_title FROM whatismoney.account_book WHERE userid = ? AND MONTH(created_at) = 10 AND category = ?';
    connection.query(sql, [userid, hobby], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: '오류가 발생했습니다.' });
        }

        if (result.length === 0) {
            return res.status(401).json({ error: '데이터를 찾을 수 없습니다.' });
        }

        // 결과 배열을 저장할 빈 배열 생성
        const data = [];

        // 결과 배열을 반복하며 데이터 추출
        result.forEach((row) => {
            data.push({
                category: row.category,
                income_spending: row.income_spending, 
                spending_title: row.spending_title
            });
        });

        // 클라이언트에 응답 전송
        return res.status(200).json({
            data: data
        });
    });
};

exports.getetc = (req, res) => {
    const { userid } = req.body;

    const etc = '기타';

    const sql = 'SELECT category, income_spending, spending_title FROM whatismoney.account_book WHERE userid = ? AND MONTH(created_at) = 10 AND category = ?';
    connection.query(sql, [userid, etc], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: '오류가 발생했습니다.' });
        }

        if (result.length === 0) {
            return res.status(401).json({ error: '데이터를 찾을 수 없습니다.' });
        }

        // 결과 배열을 저장할 빈 배열 생성
        const data = [];

        // 결과 배열을 반복하며 데이터 추출
        result.forEach((row) => {
            data.push({
                category: row.category,
                income_spending: row.income_spending, 
                spending_title: row.spending_title
            });
        });

        // 클라이언트에 응답 전송
        return res.status(200).json({
            data: data
        });
    });
};

exports.getcontent = (req, res) => {
    const { userid } = req.body;

    // 이번 달
    var now = new Date();
    var month = now.getMonth() + 1;

    const sql = 'SELECT category, SUM(income_spending) as total FROM whatismoney.account_book WHERE userid = ? AND MONTH(created_at) = ? GROUP BY category';
    connection.query(sql, [userid, month], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: '오류가 발생했습니다.' });
        }

        if (result.length === 0) {
            return res.status(401).json({ error: '데이터를 찾을 수 없습니다.' });
        }

        // 결과 배열을 저장할 빈 배열 생성
        const data = [];

        // 결과 배열을 반복하며 데이터 추출
        result.forEach((row) => {
            data.push({
                category: row.category,
                income_spending: row.total // total이 SUM(income_spending)의 결과
            });
        });

        // 클라이언트에 응답 전송
        return res.status(200).json({
            data: data
        });
    });
};

