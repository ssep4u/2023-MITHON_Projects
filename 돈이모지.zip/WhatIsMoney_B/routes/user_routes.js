const express = require('express');
const router = express.Router();
const userController = require('../controllers/user_controller'); // 사용자 컨트롤러 가져오기  

// 회원가입 라우트
router.post('/signup', userController.signup);

// 아이디 중복 확인 라우트
router.post('/check-duplicate', userController.checkDuplicate);

// 인증번호 전송 라우트
router.post('/certificate', userController.certificate);

// 인증번호 확인 라우트
router.post('/checkAuthCode', userController.checkAuthCode);

// 로그인 라우트
router.post('/login', userController.login);

// 초기 프로필 설정 라우트
router.post('/setProfile', userController.setProfile);

// 일기, 가계부, 상태 입력창 라우트
router.post('/saveAccountEntry', userController.saveAccountEntry);

// 월 카테고리 불러오기 라우트
router.post('/getcontent', userController.getcontent);

// 상세 카테고리 불러오기 라우트
router.post('/gettraffic', userController.gettraffic);

// 상세 카테고리 불러오기 라우트2
router.post('/geteat', userController.geteat);

// 상세 카테고리 불러오기 라우트3
router.post('/gethobby', userController.gethobby);

// 날짜 상태 불러오기
router.post('/getUserData', userController.getUserData);

module.exports = router;