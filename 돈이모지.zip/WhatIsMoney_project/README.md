# WhatIsMoney_project
이번 달 소비 내역을 이모지와 함께 기록하는 앱
